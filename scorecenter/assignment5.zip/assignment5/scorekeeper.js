var Db = require('mongodb').Db;
var Connection = require('mongodb').Connection;
var Server = require('mongodb').Server;
var BSON = require('mongodb').BSON;
var ObjectID = require('mongodb').ObjectID;
var express = require('express'); 

var app = express();
app.configure(function() { 
	app.use(express.methodOverride()); 
	app.use(express.logger('dev'));
	app.use(express.bodyParser());
	app.use(app.router); 
}); 

var mongoUri = process.env.MONGOLAB_URI || process.env.MONGOHQ_URL ||
			   'mongodb://localhost/scorecenter';
var mongo = require('mongodb');

var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
		db = databaseConnection;		
		}); 

function findAll(req, res) 
{
	db.collection('scores', function(err, collection) {
		collection.find().toArray(function (err, items) {
			res.render('index', { items: items, title: 'All Score Information' }); 
		});  
	});  
} 
exports.findAll = findAll; 

function getUser(req, res)
{
	res.render('search', {title: "UserSearch"}); 
}
exports.getUser = getUser;

function addScore(req, res)
{
	var score = {
		game_title: req.body.game_title,
		username: req.body.username,
		score: Number(req.body.score), 
		created_at: new Date()
	}; 
	db.collection('scores', function(err, collection) {
		collection.insert(score, {safe:true}, function(err, result) {
			if(err) {
				res.send({'error': 'an error has occurred'});
			} else {
				console.log("added " + result);
				}
			});
		});  
}

exports.addScore = addScore; 

function findName(req, res)
{
	db.collection('scores', function(err, collection) {
		collection.find({username: req.body["username"]}).toArray(function(err, items) {
			if(err) {
				res.send("Sorry. Username not found.");
			}
			else {
				res.render('usernames', {items: items, 
					title: 'Highscores for user: ' + req.body["username"]}); 
			}
		});
	}); 

}
exports.findName = findName;

function findGame(req, res)
{
    res.header("Access-Control-Allow-Origin", "*"); 
    res.header("Access-Control-Allow-Headers", "X-Requested-With");
	db.collection('scores', function(err, collection) {
		collection.find(
			{game_title: req.query["game_title"]}).sort( {score: -1 })
			.limit(10).toArray(function(err, item) {
			if(err){
				res.send("Sorry. Game Not Found.");
			}
			else {
				res.send(JSON.stringify(item)); 
			}
			});
		});
}
exports.findGame = findGame; 

function stylemain(req, res) {
	res.sendfile(__dirname + "/stylesheets/stylemain.css"); 
}
exports.stylemain = stylemain; 

