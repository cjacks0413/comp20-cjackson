var http = require("http");
var url = require("url"); 
var requestHandlers = require("./requestHandlers"); 
var scoreKeeper = require("./scorekeeper"); 
var express = require("express"); 
var app = express(); 
var port = process.env.PORT || 5000; 
app.engine('jade', require('jade').__express); 
app.set('views', __dirname + '/views'); 
app.set('view engine', 'jade'); 
app.configure(function() { 
	app.use(express.methodOverride()); 
	app.use(express.logger('dev'));
	app.use(express.bodyParser());
	app.use(function(req, res, next) {
		res.header("Access-Control-Allow-Origin", "*");
		res.header("Access-Control-Allow-Origin", "X-Requested-With");
		next();
	}); 
	app.use(app.router); 
}); 

app.all('/', function(req, res, next) {
	res.header("Access-Control-Allow-Origin", "*");
	res.header("Access-Control-Allow-Headers", "X-Requested-With");
	next();
}); 

app.get('/', scoreKeeper.findAll);
app.get('/index.html', scoreKeeper.findAll);
app.get('/username', scoreKeeper.getUser);
app.get('/highscores.json', scoreKeeper.findGame);
app.get('/stylemain.css', scoreKeeper.stylemain); 
app.post('/username', scoreKeeper.findName); 
app.post('/submit.json', function(req, res) {
	res.header("Access-Control-Allow-Origin", "*");
	res.header("Access-Control-Allow-Headers", "X-Requested-With"); 
	scoreKeeper.addScore(req, res); 
}); 

	
app.listen(port); 
